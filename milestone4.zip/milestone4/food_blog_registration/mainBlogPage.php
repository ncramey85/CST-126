<?php
$servername = "localhost";
$username = "root";
$password = "root";
$database_name = "food_blog_database";

$connection = new mysqli($servername, $username, $password, $database_name);
if ($connection -> connect_error){
    die("Connection failed: " . $connection -> connect_error);
}
$sql = "SELECT USERNAME, RESTAURANT_NAME, CUISINE_TYPE, ACTUAL_BLOG FROM blogposts";
$result = $connection -> query($sql);
if ($result -> num_rows > 0)
{
echo 
"<table>
<tr><th>User Name
</th><th>Restaurant Name 
</th><th>Cuisine Type
</th></tr>";
while ($row = $result -> fetch_assoc())
{        
echo "<tr><td>" . $row["inputUserName"] . "</td><td>" . $row["restaurant_name"] . "</td><td>" . $row["cuisine_type"] . "</td></tr>";
}
echo "</table>";
} 
else 
{
echo "0 results";
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<style>
	table, th, td{
		border: 5px solid #c4c4c4;
		padding: 25px;
}
hr
{
		border: 5px solid #c4c4c4;
		margin-bottom: 25px;
}
*{
		background-color:#8d96fc ;
}
</style>
</head>
<body>
	<a href="newBlog.html"> New Blog Post </a>
</body>
</html>