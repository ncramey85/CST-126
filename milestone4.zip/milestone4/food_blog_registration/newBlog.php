<?php

$userName=$_POST["inputUserName"];
$restuarantName=$_POST['restaurant_name'];
$cuisine=$_POST['cuisine_type'];
$blogPost=$_POST['actual_blog'];


$servername = "localhost";
$username = "root";
$password = "root";
$database_name = "food_blog_database";

$connection = new mysqli($servername, $username, $password, $database_name);
if ($connection -> connect_error)
{
die("Connection failed: " . $connection -> connect_error);
}
$query = "INSERT  INTO `blogposts` (`USERNAME`, `RESTAURANT_NAME`, `CUISINE_TYPE`, `ACTUAL_BLOG`) 
    VALUES ('$userName', '$restuarantName', '$cuisine', '$blogPost')";
if ($connection -> query($query) === TRUE)
{
echo "New Blog Post uploaded successfully";
} 
else 
{
echo "Error: " . $query . "<br>" . $connection -> error;
}
$database_name -> close();
?>

<html>
	<a href="mainBlogPage.html">Main Page</a><br/><br/>
</html>