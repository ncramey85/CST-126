<?php
$servername = "localhost";
$username = "root";
$password = "root";
$database_name = "activity2";
$userName = $_POST['inputUsername'];
$userPassword = $_POST['inputPassword'];

if($userName == NULL)
{
echo "Error: Username is a required field and cannot be blank.";
}
else
{
if($userPassword == NULL)
{
echo "Error: Password is a required field and cannot be blank.";
}
else
{       
$connection = mysqli_connect($servername, $username, $password, $database_name);
        
$sql_statement = "SELECT * FROM `users` WHERE `USERNAME` LIKE '$userName' AND `PASSWORD` LIKE '$userPassword'";
$result = mysqli_query($connection, $sql_statement);
        
if (mysqli_num_rows($result) == 0)
{
echo "Login was Successful";
}
else if(mysqli_num_rows($result) == 1)
{
echo "Login Failed";
}
else
{
echo "Database Error";
}
}
}
?>