<?php

$servername = "localhost";
$username = "root";
$password = "root";
$database_name = "activity2";
$firstName = $_POST['inputFirstName'];
$lastName = $_POST['inputLastName'];
$userName = $_POST['inputUserName'];
$userPassword = $_POST['inputPassword'];

if($firstName == NULL)
{
    echo "First Name is a required field and cannot be blank";
}
else

if($lastName == NULL)
{
echo "Last Name is a required field and cannot be blank";
}
else 
{
$connection = mysqli_connect($servername, $username, $password, $database_name);

if(!$connection)
{
die(" Connection failed successfully: ".mysqli_connect_error());
}
echo "Connected successfully";

$sql_statement = "INSERT INTO `users` (`ID`, `FIRST_NAME`, `LAST_NAME`, `USERNAME`, `PASSWORD`) VALUES(NULL,'$firstName','$lastName','$userName','$userPassword')";
if(mysqli_query($connection,$sql_statement))
{
echo " and New Record Made ";
}
else
{
echo " Error, cannot connect.: " . $sql_statement . "<br>" . mysqli_error($connection);
}
mysqli_close($connection);
}
?> 