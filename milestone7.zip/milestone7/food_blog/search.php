<?php 

include 'main.css';
include 'functions.php';

$connection = dbConnect();
$search = $_POST['search'];
$sql_statement = "SELECT * FROM `blogposts` WHERE `RESTAURANT_NAME` LIKE '%$searchForRestaurant%' OR `CUISINE_TYPE` LIKE
'%$searchForCuisine%";
?>

<html>
<body background="turkey_octopus.jpg">
	<?php $result = $connection -> query($sql); ?>
	<table id= Search 1>
		<tr>
		<th>Restaurant Name</th>
		<th>Cuisine Type</th>
       	</tr> 
       	<?php while ($row = $result -> fetch_assoc()): ?>
       	<tr>
	    <td> <?php echo $row["RESTAURANT_NAME"]; ?> </td>
	    <td> <?php echo $row["CUISINE_TYPE"]; ?> </td>
	    </tr>
	    <?php endwhile; ?>
	</table>
	<?php connectionClose(); ?>
</body>	
</html>