<?php

include 'main.css';
include 'functions.php';

$connection = dbConnect();

if (isset($_GET['ID'])) {
    try {
        echo $_GET['ID'];
        global $connection;
        
        $sql = "SELECT * FROM blogposts WHERE ID = :ID";
        $statement = $connection -> prepare($sql);
        $statement -> bind_result(":ID", $id);
        $statement -> execute();
        $user = $statement->fetch(PDO::FETCH_ASSOC);
    } catch (PDOException $error){
        echo $sql . "<br>" . $error -> getMessage();
    }
} else {
    echo "Nothing went right.";
    exit;
}
connectionClose();
?>