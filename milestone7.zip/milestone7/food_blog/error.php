<?php
include 'main.css';
?>
<html>
	<body>
	
		<p>Invalid Entry/Request.  
		
		<a href="mainBlogPage.php"> Go Back </a> 
		
		Try again </p>
	</body>
</html>