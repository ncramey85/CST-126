<?php

include 'main.css';
include 'functions.php';

$connection = dbConnect();

if(isset($_POST["id"]) && !empty($_POST["id"])){
    $sql = "DELETE FROM blogposts WHERE id = ?";
    if ($stmt = mysqli_prepare($link, $sql)){
        mysqli_stmt_bind_param($stmt, i, $param_id);
        $param_id = trim($_POST["id"]);
        if (mysqli_stmt_execute($stmt)){
            header("Location: mainBlogPage.php");
            exit();
        } else {
            echo "Something went wrong.";
        }
    }
    mysqli_close($link);
} else {
    if(empty(trim($_GET["id"]))){
        header("Location: error.php");
        exit();
    }
}
$close = connectionClose();
?>
<html>
<body>
	<br/>
	<a href="mainBlogPage.php">Main page</a> <br/>
	<p>Delete this blog?</p><br/>
	<input type="submit" value="Yes">
	<a href="mainBlogPage.php" class="btn btn-default">No</a>
</body>
</html>