<?php

$_SESSION['userName']=$userName;
$userName=$_POST["inputUserName"];
$restuarantName=$_POST['restaurant_name'];
$cuisine=$_POST['cuisine_type'];
$blogPost=$_POST['actual_blog'];

include 'main.css';
include 'functions.php';
$conn = dbConnect();

$query = "INSERT  INTO `blogposts` (`USERNAME`, `RESTAURANT_NAME`, `CUISINE_TYPE`, `ACTUAL_BLOG`)
    VALUES ('$userName', '$restuarantName', '$cuisine', '$blogPost')";

if ($conn->query($query) === TRUE){
    echo "Blog created successfully";
} else {
    echo "Error: " . $query . "<br>" . $conn->error;
}
$close = connectionClose();
?>

<html>
	<a href="mainBlogPage.php">Main Page</a><br/><br/>
</html>
