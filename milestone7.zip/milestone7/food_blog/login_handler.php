<?php

include 'main.css';
include 'functions.php';

$connection = dbConnect();

session_start();
$userName = $_POST['userName'];
$userRole = $_POST["userRole"];

if($userName == NULL){
    echo("A username is required");
}
if ($userRole == NULL){
    echo("User role is required");
}
$sql = ("SELECT USERNAME, USERROLE FROM users WHERE USERNAME=" . mysqli_real_escape_string($_POST['userName']) . 
        "AND USERROLE=" . mysqli_real_escape_string($_POST['userRole']));
$captured = $connection -> query($sql);

if($captured -> num_rows = 1){
    echo "<p>Login was successful</p>" . $userName;
} else if ($captured -> num_rows = 0){
    echo "Login Failed";
} else if ($captured -> num_rows > 2){
    echo "Multiple users that have registered named";
} else {
    echo $connection -> error;
}
connectionClose();

?>
<html>
<body background="burrito.jpg">
	<br/><br/>
	
<?php if ($userRole == "administrator"){
		  echo "<a href='administrator.php'> Administration Page </a>";
		} 
		else 
		{
		echo "<a href='mainBlogPage.php'> Main Blog </a>";
		}
		function goBack() {
		  window.history.back();
		}?>
		<br><br>
		<a href='newBlog.php'> New Blog </a><br><br>
		<button onclick="goBack()">Back</button>
	<script>
		function goBack(){
			window.history.back();
		}
	</script>
	</body>
</html>