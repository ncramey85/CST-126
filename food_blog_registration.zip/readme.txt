This assignemnt contains all the work for week 1.
Week 1 consisted of Activity 1 and Milestone 1.
Activity 1 was a crash course in getting PHP,MySQL to function properly using Eclipse PHP and MAMP.
Milestone 1 is a basic registration form to make an account with a blog. 
