<?php
$servername = "localhost";
$username = "root";
$password = "root";
$database_name = "food_blog_database";

$userName = $_POST['inputUsername'];
$userPassword = $_POST['inputPassword'];

if($userName == NULL)
{
echo "Error: The Username is a required field.";
}
else
{
if($userPassword == NULL)
{
echo "Error: The Password is a required field.";
}
else
{
        
$connection = mysqli_connect($servername, $username, $password, $database_name);
        
$sql_statement = "SELECT * FROM `users` WHERE `USERNAME` LIKE '$userName' AND `PASSWORD` LIKE '$userPassword'";
$result = mysqli_query($connection, $sql_statement);     
if (mysqli_num_rows($result) == 1)
{
echo "Successful Login";
}
else if(mysqli_num_rows($result) == 0)
{
echo "Login Failed Successfully";
}
else   
{
echo "Database Error";
}
}
}

?>