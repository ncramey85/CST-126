<?php
$servername = "localhost";
$username = "root";
$password = "root";
$database_name = "food_blog_database";
$userFirstName = $_POST['firstNameInput'];
$userLastName = $_POST['lastNameInput'];
$userEmail = $_POST['emailInput'];
$userCuisine = $_POST['cuisineInput'];
$userPassword = $_POST['passwordInput'];

//Initial databse connection
$connection = mysqli_connect($servername, $username, $password, $database_name); 

//See if connection was successful or failed.
if(!$connection) 
{
    die("Failed at connecting to server: " . mysqli_connect_error());
}
echo ("Server connected successfully\n");

//Pushes data into database
$sql_statement = "INSERT INTO `users` (`ID`, `FIRST_NAME`, `LAST_NAME`, `EMAIL`,`PREFERRED_CUISINE`,`PASSWORD`) VALUES(NULL,'$userFirstName','$userLastName','$userEmail','$userCuisine','$userPassword')"; 

if(mysqli_query($connection,$sql_statement)) 
{
echo("User profile created:");
}
else
{
echo "Error failed successfully: " . $sql_statement . "<br>" . mysqli_error($connection);
}
mysqli_close($connection);
?> 