<?php
function dbConnect (){
$servername = "localhost";
$username = "root";
$password = "root";
$database_name = "activity2";

$connection = mysqli_connect($servername, $username, $password, $database_name);
if(!$connection)
{
die("Connection Failed: " . $connection -> connect_error());
}
return mysqli_close($connection);
}

function saveUserId($id) {
    session_start();
    $_SESSION["USER_ID"] = $id;
}
function getUserId() {
    session_start();
    return $_SESSION["USER_ID"];
}
?>