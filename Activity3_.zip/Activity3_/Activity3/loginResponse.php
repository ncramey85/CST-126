<?php
?>
<!DOCTYPE html>
<html>
<head>
<title>Login Response</title>
</head>
<body>
	<h2>Login was successful: <?php  echo " ".$message ?></h2>
	<a href="whoAmI.php">Who Am I</a>
</body>
</html>