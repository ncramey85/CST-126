<?php

require_once 'myfuncs.php';

$servername = "localhost";
$username = "root";
$password = "root";
$database_name = "activity2";
$userName = $_POST['inputUsername'];
$userPassword = $_POST['inputPassword'];

$connection = dbConnect();

if($userName == NULL)
{
echo "Error: Username is a required field and cannot be blank.";
}
else
{
if($userPassword == NULL)
{
echo "Error: Password is a required field and cannot be blank.";
}
else
{               
$sql_statement = "SELECT * FROM `users` WHERE `USERNAME` LIKE '$userName' AND `PASSWORD` LIKE '$userPassword'";
$result = mysqli_query($connection, $sql_statement);
        
if (mysqli_num_rows($result) == 0)
{
$row = $captured->fetch_assoc();
saveUserId($row["ID"]);
include ('loginResponse.PHP');
}
else if(mysqli_num_rows($result) == 1)
{
$message = "Login Failed";
include('loginFailed.php');
}
else if (mysqli_num_rows($result) > 2) 
{
echo "That Username is already taken";
}
}
}
$connection ->close();
?>