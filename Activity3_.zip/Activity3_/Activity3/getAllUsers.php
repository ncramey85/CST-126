<?php
$servername = "localhost";
$username = "root";
$password = "root";
$database_name = "activity1";

$connection = mysqli_connect($servername, $username, $password, $database_name);

if(!$connection)
{
die("Connection Failed: " . $connection -> connect_error());
}

$select = "SELECT ID, FIRST_NAME, LAST_NAME FROM `users`";
$captured = $connection -> query ($select);

if ($captured -> num_rows > 0)
{
while($row = $captured -> fetch_assoc())
{
echo "ID: " . $row["ID"]. " - Name: " . $row["FIRST_NAME"]. " " . $row["LAST_NAME"]. "<br>";
}
}
else
{
echo "0 results";
}
$connection -> close();
?>