<?php
require_once 'myfuncs.php';

$servername = "localhost";
$username = "root";
$password = "root";
$database_name = "activity2";
$firstName = $_POST['inputFirstName'];
$lastName = $_POST['inputLastName'];
$userName = $_POST['inputUserName'];
$userPassword = $_POST['inputPassword'];

$connection = dbConnect();

$sql_statement = "INSERT INTO `users` (`ID`, `FIRST_NAME`, `LAST_NAME`, `USERNAME`, `PASSWORD`) VALUES(NULL,'$firstName','$lastName','$userName','$userPassword')";
if(mysqli_query($connection,$sql_statement))

if($firstName == NULL)
{
echo "First Name is a required field and cannot be blank";
}
if($lastName == NULL)
{
echo "Last Name is a required field and cannot be blank";
}
if($userName == NULL)
{
echo "Username is required";
{
if($userPassword == NULL)
echo "Password is required";
}
{
if(!$connection)
{
    echo " and New Record Made ";
}
else
{
    echo " Error, cannot connect.: " . $sql_statement . "<br>" . mysqli_error($connection);
}
mysqli_close($connection);
}
}
?> 