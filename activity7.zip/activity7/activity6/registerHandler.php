<?php

$firstName = $_POST["firstName"];
$lastName = $_POST["lastName"];
$user = $_POST["username"];
$password = $_POST["password"];

include 'myfuncs.php';

$connect = dbConnect();

$sql = "INSERT INTO users (firstName, lastName, username, password) VALUES ('$firstName', '$lastName', '$user', '$pass')";
if ($firstName == NULL){
    echo ("The first name is a required field that can not be left blank\n");
}
if ($lastName == NULL){
    echo ("The last name is a required field that can not be left blank\n");
}
if ($user == NULL){
    echo ("The username is a required field that can not be left blank\n");
}
if ($password == NULL){
    echo ("The password is a required field that can not be left blank\n");
}
if (!($firstName == NULL || $lastName == NULL || $user == NULL || $password == NULL) && $connection -> query($sql) === TRUE){
    echo "New record created!";
} else {
    echo "Error: " . $sql . "<br/>" . $connection -> error;
}
$connection -> close();
?>