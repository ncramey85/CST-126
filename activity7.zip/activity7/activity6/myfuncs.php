<?php

$servername = "localhost";
$username = "root";
$password = "root";
$database_name = "activity1";

function dbConnect() {
    global $servername, $username, $password, $database_name;
    $connection = new mysqli($servername, $username, $password, $database_name);
    if ($connection -> connect_error){
        echo  $connection -> connect_error;
    }
    return $connection;
    
    function getUserId(){
        session_start();
        return $_SESSION["ID"];
    }
    function saveUserId($user){
        session_start();
        $_SESSION["ID"]=$id;
    }
    function closeConnection($connection){
        $connection -> close();
    }
   }
?>