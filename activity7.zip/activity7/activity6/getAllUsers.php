<?php
$servername = "localhost";
$username = "root";
$password = "root";
$database_name = "activity1";

$connection = new mysqli($servername, $username, $password, $database_name);
if ($connection -> connect_error){
    die("Connection failed: " . $connection -> connect_error);
}
$select = "SELECT ID, firstName, lastName FROM users";
$captured = $connection -> query($select);
if ($captured -> num_rows > 0){
    while ($row = $captured -> fetch_assoc()){
        echo "ID: " . $row["ID"] . " Name: " . $row["firstName"] . " " . $row["lastName"] . "<br/>";
    }
} else {
    echo "Users Not Available.";
}
$connection -> close();
?>