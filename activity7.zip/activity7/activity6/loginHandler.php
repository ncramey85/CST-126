<?php
$user = $_POST["username"];
$password = $_POST["password"];

include('myfuncs.php');
include '_displayUsers.php';

dbConnect();

$sql = "SELECT * FROM users WHERE username='$user' AND password='$password' ";
$captured = dbConnect() -> query($sql);

if($captured -> num_rows = 1){
    include("loginResponse.php");
} else if ($captured->num_rows = 0){
    include("loginFailed.php");
} else if ($captured->num_rows > 2){
    echo "Duplicate users already registered with that username";
} else {
    echo dbConnect() -> error;
}
if($user == NULL || $pass == NULL){
    echo ("Username/Password are required fields.\n");
}
$row = $result -> fetch_assoc(); 
saveUserId($row["ID"]); 
closeConnection($connection);

?>