<?php
$message = "Login Failed";
?>
<html>
	<head>
	</head>
	<body>
		<h2><?php $message?></h2>	
		<a href="login.html"> Try again </a>
	</body>
</html>