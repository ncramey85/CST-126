<?php

require_once ('utility.php');
$users = getAllUsers();
include ('_displayUsers.php');
?>

<html>
<body>
    <table>
    </table>
</body>
</html>