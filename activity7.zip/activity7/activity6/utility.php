<?php
include ('myfuncs.php');
function getAllUsers(){
    $index;
    $users=array();
    $connect = dbConnect();
    $sql = "SELECT * FROM users";
    $result = $connect->query($sql);
    if($result->num_rows > 0){
        while ($row = $result->fetch_assoc()){
            $index;
            $users[$index] = array($row["id"], $row["firstName"], $row["lastName"]);
            ++$index;
        }
    }
    return $users;
}
function getUsersByFirstName(){
    $index;
    $users = array();
    $connect = dbConnect();
    global $searchPattern;
    $sql = "SELECT firstName FROM users";
    $result = $connect->query($sql);
    if($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()){
            global $index;
            $users[$index] = array($row["id"], $row["firstName"], $row["lastName"]);
            ++$index;
        }
    }
    return $users;
}
function insertUsers(){
    $connection = dbConnect();
    $sql = "SELECT id, firstName, lastName FROM users";
    $result = $connection -> query($sql);
    if ($result -> num_rows == 0){
        echo "<b>No users in the database.</b>";
    }
    $index = 0;
    $users = array();
    while ($row = $result -> fetch_assoc()){
        $users[$index] = array($row['id'], $row['firstName'], $row['lastName']);
        ++$index;
    }
    $connection -> close();
    return $users;
}
?>