<?php
$firstName= $_POST["firstName"];
$lastName= $_POST["lastName"];

$servername = "localhost";
$username = "root";
$password = "root";
$database_name = "activity1";

$connection = new mysqli($servername, $username, $password, $database_name);
if ($connection -> connect_error){
    die("Connection failed: " . $connection -> connect_error);
}
$sql = "INSERT INTO users (firstName, lastName) VALUES ('$firstName', '$lastName')";

if(empty($firstName)){echo "First name is required. Please enter all information.";
}
if(empty($lastName)){ echo "Last name is required. Please enter all information.";   
}
if(!($firstName == NULL || $lastName == NULL) && $connection -> query($sql) === TRUE){ echo "Registration Successful!";
} 
else {echo "Error: " . $sql . "<br/>" . $connection -> error;
}
$connection -> close();
?>