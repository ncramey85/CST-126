?>
<html>
<body background='batman-vs-superman.jpg'>
	<?php 
        require_once 'Superman.php';
        require_once 'Batman.php';
        
        $lost = 0;
        $batman = new Batman();
        $superman = new Superman();
        
        echo "<table style='border: 5px solid black; padding: 16px; color: #ffff00; font-size: 35px;'>";
            echo "<tr>";
                echo "<th>Hero</th>
                      <th>Health</th>
                      <th>Dead</th>";
            echo "</tr>";
            while ($lost == 0) {
                if (($batman -> isDead() == 'false') && ($superman -> isDead() == 'false')){
                    $batman -> Attack(mt_rand(1, 10));
                    if ($batman -> isDead() != 'true') {
                        $superman -> Attack(mt_rand(1, 10));
                    }
                }
                if (($batman -> isDead() == 'true') && ($batman -> isDead() == 'false')){
                    echo '<span style="display: center; width: 500px; padding-bottom: 10px; font-size: 45px; color: #ffff00;">
                    Superman Won! But his home planet was destroyed making him extrememly lonely since he is only one of his kind.</span>';
                    $lost = 1;
                }
                if (($superman -> isDead() == 'true') && ($batman -> isDead() == 'false')){
                    echo '<span style="display: center; width: 500px; padding-bottom: 10px; font-size: 45px; color: #ffff00;">
                    Batman Won! But his parents are still dead...</span>';
                    $lost = 1;
                }
            }
?>
</body>
</html>