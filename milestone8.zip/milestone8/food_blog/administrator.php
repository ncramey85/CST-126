<?php
include 'functions.php';
$connection = dbConnect();

$sql = "SELECT ACTUAL_BLOG, CUISINE_TYPE, USERNAME, RESTAURANT_NAME FROM blogposts";
include 'main.css';

session_start();
$_SESSION['userName'] = $userName;
?>

<!DOCTYPE html>
<html>
    <body background="meat_bloody_mary.jpg">
    <h1 align="center">Welcome!</h1>
    	
<?php 
echo $userName; 
?>
    	<br/>
    	<section>
    		<nav>
    			<ul>
<li><a href="newBlog.html">Create a new Blog</a></li>
<li><a href="readBlog.php">Read other Blogs</a></li>
    			</ul>
    		</nav>
    		<article>
<?php 
$result = $connection -> query($sql); 
?>
				<table id=blogTable>
	   			<tr>
        			<th>User Name</th>
        			<th>Title</th>
        			<th>Category</th>
       			</tr> 
<?php 
while ($row = $result->fetch_assoc()):
?>
	      		<tr>
	        		<td> <?php echo $row["userName"]; ?> </td>
	        		<td> <?php echo $row["restuarant_name"]; ?> </td>
	       		 	<td> <?php echo $row["actual_blog"]; ?>  </td>
	        	</tr>
	        	</table>
<?php 
endwhile; 
?>
<?php 
connectionClose(); 
?>
    		</article>
    	</section>	       
    	<button onclick="goBack()">Back</button><br/><br/>
    	<script>
        	function goBack(){
        	    window.history.back();
        	}
    	</script><br/>
	</body>
</html>
