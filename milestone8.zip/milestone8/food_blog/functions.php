<?php

$servername = "localhost";
$username = "root";
$password = "root";
$database_name = "foodblog";

function dbConnect()
{
    global $servername, $username, $password, $database_name;
    $connection = new mysqli($servername, $username, $password, $database_name);
    if ($connection -> connect_error){
        die("Connection failed: " . $connection -> connect_error);
    }
    return $connection;
}
function connectionClose(){
    global $connection;
    return $connection -> close();
}
?>