<?php
include 'main.css';
?>
<html>
<body background="turkey_octopus.jpg">
	<h1 align="left" style="color:violet">Search for Users</h1>
	<form method="post" align="left" style="color:#80bfff">
		Specfic Blog you want to find:<br><br>
		
		<input type="text" name="search" placeholder="Restaurant Name"><br></br>
		<input type = "text" name ="search" placeholder = "Cuisine Type"><br></br>
		<input type="submit" formaction="search.php" value="Submit" name="Submit">
		
	</form>
	<br><br>
	<button onclick="goBack()"> Back </button>
	<script>
		function goBack() {
			window.history.back();
		}	
	</script>
</body>		
</html>