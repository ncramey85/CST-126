<?php

    include 'main.css';
    include 'functions.php';
    
    $connection = dbConnect();
    
    $sql = "SELECT * FROM blogposts";
    session_start();
    $userName = $_SESSION['userName'];
?>
<!DOCTYPE html>
<html>
	<body background="nasty.jpg">
		<h1 align="center"><strong> Chewing the fat through the blog.</strong></h1><br/>
	<center><button onclick="goBack()">Back</button><br/><br/></center>
    	<script>
        	function goBack(){
        	    window.history.back();
        	}
    	</script><br/>
<?php 
		$result = $connection -> query($sql); ?>
    	<table align = "center" id=blogTable>
    	   <tr>
            <th>ID</th>
            <th>User Name</th>
            <th>Restaurant Name</th>
            <th>Cuisine</th>
            <th>Blog</th>

           </tr> 
<?php 
        while ($row = $result -> fetch_assoc()): ?>
    	    <tr>
    	    <td> <?php echo $row["id"]; ?> </td>
    	    <td> <?php echo $row["userName"]; ?> </td>
    	    <td> <?php echo $row["restaurant_name"]; ?>  </td>
    	    <td> <?php echo $row["cuisine"]; ?> </td>
    	    <td> <?php echo $row["blogPost"]; ?> </td>
    	    </tr>
    	    
<?php 
endwhile; 
?>
    		</table>
<?php
connectionClose(); 
?>
	</body>
</html>