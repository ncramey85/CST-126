<?php
include 'main.css';
include 'functions.php';

$connection = dbConnect();

$id = $_POST['hidden'];
$mysql = "SELECT * FROM comments WHERE id = $id";
?>
<html>
<body>

<button onclick="goBack()">Back</button>
		<a href="logoutBlog.php"><button>Logout</button></a>
<script>
	
function goBack(){
	window.history.back();
		}
	</script>
	<br>
	<section>
	<article>
<?php 
$result = $connection -> query($mysql);	
?>
	<table id = commentTable style="background-color: #5BD0F9;">
		<tr style="color:#DCB007 ;">
			<th>Comments</th>
		</tr>
<?php 
while ($row = $result -> fetch_assoc()):
?>
		<form method="post">
		<tr>
			<td> <?php echo $row['comment']; ?> </td>
		</tr>
		</form>
<?php
endwhile; 
?>
	</table>
<?php 
connectionClose(); 
?>
	</article>
	<aside>
	<form method="post" action="commentsAdd.php">
	Add comments: <br><br>
	<textarea rows="20" cols="50" name='comment'>Comments Here</textarea>

	<button onclick='commentsAdd.php'>Submit</button>
	</form>
	</aside>
	</section>
</body>
</html>