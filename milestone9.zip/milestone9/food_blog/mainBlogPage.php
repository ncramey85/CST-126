<?php
$servername = "localhost";
$username = "root";
$password = "root";
$database_name = "foodblog";

include 'functions.php';

$connection = dbConnect();
$sql = "SELECT * USERNAME, CUSINE_TYPE, RESTAURANT_NAME FROM blogposts";

include 'main.css';
session_start();

$_SESSION['userName'];
?>
			<a href="mainBlogPage.php"><button>Home</button></a>
			<button onclick="goBack()">Back</button>
			<a href="logoutBlog.php"><button>Logout</button></a>
<!DOCTYPE html>
<html>
    <body background="Cooking-Fish1.jpg">
    	<br/>
    	<h1 align="center">Best (and the worst) of the Valley's Restaurants</h1>
  	<br/>
    	<a href="newBlog.html">Create A Blog Post</a><br/><br/>
    	<a href="readBlog.php">Read other Blogs</a> <br/><br/>	       
    	<a href="search.php"> Search For Specfic Blog</a><br/>
    	
    	<button onclick="goBack()">Back</button><br/><br/>
    	<script>
        	function goBack(){
        	    window.history.back();
        	}
    	</script><br/>
<?php $result = $connection -> query($sql); 
?>
	<table id=blogTable>
	   <tr>
        <th>User:</th>
        <th>Restaurant Visited</th>
        <th>Cuisine Type</th>
       </tr> 
<?php 
while ($row = $result -> fetch_assoc()): 
?>
	        <tr>
	        <td> 
<?php 
echo $row["userName"]; 
?> </td>
	        <td> 
<?php 
echo $row["restaurant_name"];
?> </td>
	        <td> 
<?php 
echo $row["cuisine_type"]; 
?>  </td>
	        </tr>
<?php 
endwhile; 
?>
	</table>
<?php 
connectionClose(); 
?>
	</body>
</html>