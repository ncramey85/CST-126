<?php
include 'functions.php';
$connection = dbConnect();

$sql = "SELECT userName, FROM blogposts";
include 'main.css';

session_start();

?>
<!DOCTYPE html>
<html>
    <body background="smoothie.jpg">
    <h1 align="center">Welcome!</h1>
<?php echo 
 $_SESSION['userName']; 
?>
    	<br/>
			<a href="mainBlogPage.php"><button>Home</button></a>
			<button onclick="goBack()">Back</button>
			<a href="logoutBlog.php"><button>Logout</button></a>
		<script>
			function goBack(){
				window.history.back();
			}
		</script>
		<br>
    	<section>
    		<nav>
    			<ul>
    				<li><a href="newBlog.html"><button>Create a new Blog Post</button></a></li>
    				<br><br>
    				<li><a href="readBlog.php"><button>Read Blogs</button></a></li>
    				<br><br>
    				<li><a href="searchUser.php"><button>Search Users</button></a></li>
    			</ul>
    		</nav>
    		<article>
<?php 
$result = $connection -> query($sql); 
?>
				<table id=blogposts>
	   			<tr>
        			<th>User Name</th>
        			<th>Restaurant</th>
        			<th>Cuisine Type</th>
       			</tr> 
<?php 
while ($row = $result->fetch_assoc()): 
?>
	      		<tr>
	        		<td> <?php echo $row["userName"]; ?> </td>
	        		<td> <?php echo $row["restaurant"]; ?> </td>
	       		 	<td> <?php echo $row["cuisineType"]; ?>  </td>
	        	</tr>
<?php 
endwhile; 
?>
				</table>
<?php 
connectionClose(); 
?>
    		</article>
    	</section>	       
	</body>
</html>