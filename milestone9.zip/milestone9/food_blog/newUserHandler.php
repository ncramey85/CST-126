<?php

$userFirstName = $_POST['firstNameInput'];
$userLastName = $_POST['lastNameInput'];
$userEmail = $_POST['emailInput'];
$userCuisine = $_POST['cuisineInput'];
$userLogin = $_POST['userNameInput'];
$userPassword = $_POST['passwordInput'];

include 'main.css';
include 'functions.php';

dbConnect();

$query = "INSERT INTO `users` (`ID`, `FIRST_NAME`, `LAST_NAME`, `EMAIL`,`PREFERRED_CUISINE`,`USERNAME`,`PASSWORD`)
VALUES('$userFirstName','$userLastName','$userEmail','$userCuisine', '$userLogin','$userPassword')";
$stmt = $db -> prepare($query);
$stmt->bind_param($userFirstName,$userLastName, $userEmail);
if ($stmt->affected_rows > 0){
    echo "<p>User added to database.</p>";
} else {
    echo "<p>Cannot process.</p>";
}
connectionClose();

?>
<html>
	<a href="mainBlogPage.php">Main Page</a><br/><br/>
	
	<button align = center onclick="goBack()">Back</button>
	<script>
		function goBack(){
			window.history.back();
		}
	</script>
</html>