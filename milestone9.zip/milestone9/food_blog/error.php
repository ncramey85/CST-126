<?php
include 'main.css';
?>
<html>
<body>
	<p>Invalid request. <a href="mainBlogPage.php"> Try Again </p>
</body>
</html>