<?php

include 'main.css';
include 'functions.php';

$connection = dbConnect();

session_start();
$userName = $_POST['userName'];
$userPassword = $_POST["userPassword"];
$_SESSION['userName'] = $userName;

if($userName == NULL){
    echo("A username is required");
}
if ($userPassword == NULL){
    echo("User Password is required");
}
$mysql = ("SELECT USERNAME, PASSWORD FROM users WHERE USERNAME=" . mysqli_real_escape_string($_POST['userName']) . 
        "AND =" . mysqli_real_escape_string($_POST['PASSWORD']));
$captured = $connection -> query($mysql);

if($captured -> num_rows = 1){
    echo "<p>Login was successful</p>" . $userName;
} else if ($captured -> num_rows = 0){
    echo "Login Failed";
} else if ($captured -> num_rows > 2){
    echo "Multiple users that have registered named";
} else {
    echo $connection -> error;
}
connectionClose();

?>
<html>
<body background="burrito.jpg">
	<br/><br/>
	
<?php 
if ($userName == "administrator"){
    echo "<a href='administrator.php'> Administration Page </a>";
		} 
		else 
		{
		echo "<a href='mainBlogPage.php'> Main Blog </a>";
		}
	function goBack() {
		  window.history.back();}
?>
		<br><br>
		<a href='newBlog.html'> New Blog </a><br><br>
		<button onclick="goBack()">Back</button>
		<a href="logoutBlog.php"><button>Logout</button></a>
	<script>
	function goBack(){
			window.history.back();
		}
	</body>
</html>