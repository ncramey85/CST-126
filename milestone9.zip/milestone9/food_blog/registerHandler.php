<?php
$servername = "localhost";
$username = "root";
$password = "root";
$database_name = "foodblog";
include 'main.css';

$userFirstName = $_POST['firstNameInput'];
$userLastName = $_POST['lastNameInput'];
$userEmail = $_POST['emailInput'];
$userCuisine = $_POST['cuisineInput'];
$userLogin = $_POST['userNameInput'];
$userPassword = $_POST['passwordInput'];

$connection = mysqli_connect($servername, $username, $password, $database_name); 

include 'functions.php';
$connection = dbConnect();

session_start();
$_SESSION['userName'] = $userName;

$sql_statement = "INSERT INTO `users` (`ID`, `FIRST_NAME`, `LAST_NAME`, `EMAIL`,`PREFERRED_CUISINE`,`USERNAME`,`PASSWORD`)
VALUES($id '$userFirstName','$userLastName','$userEmail','$userCuisine', '$userLogin','$userPassword')";

if ($userFirstName == NULL){
    echo ("First Name is a required field");}
if ($userLastName == NULL){
    echo ("Last Name is a required field");}
if ($userEmail == NULL){
    echo ("Email is a required field");}
if ($userCuisine == NULL){
    echo ("Cuisine type is required field");}
if ($userLogin == NULL){
    echo ("Login is a required field");}
if ($userPassword == NULL){
    echo ("Password is a required field");}
    
if (!($userFirstName == NULL || $userLastName == NULL || $userEmail == NULL || $userCuisine == NULL || $userLogin == NULL || $userPassword == NULL) 
&& $connection -> query($query) === TRUE){
   echo "New record created successfully!";
} else {
    echo "" . $query . "<br/>" . $connection -> error;
}
$close = connectionClose();
?>
<html>
			<a href="mainBlogPage.php">
			<button onclick= "goBack()"> Home </button></a>
			<button onclick="goBack()">Back</button>
		<script>
			function goBack(){
				window.history.back();}
		</script>
		<br>
</html>