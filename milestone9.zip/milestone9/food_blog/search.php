<?php 

include 'main.css';
include 'functions.php';

$connection = dbConnect();

$search = $_POST['search'];
$sql= "SELECT * FROM `blogposts` WHERE `USERNAME` LIKE '$search' OR `%$search%`";
?>
<html>
<body>
<?php 
$result = $connection -> query($sql); 
?>
	<table id=blogTable>
		<tr>
			<th>User Name</th>
       	</tr> 
<?php 
while ($row = $result -> fetch_assoc()): 
?>
       	<tr>
	        <td> 
<?php 
echo $row["userName"]; 
?> </td>
	    </tr>
<?php 
endwhile; 
?>
	</table>
<?php 
connectionClose(); 
?>
</body>	
</html>
