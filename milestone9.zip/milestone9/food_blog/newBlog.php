<?php
session_start();
$_SESSION['userName'];
$userName=$_POST["inputUserName"];
$restuarantName=$_POST['restaurant_name'];
$cuisine=$_POST['cuisine_type'];
$blogPost=$_POST['actual_blog'];
$id = $_POST[`id`];

include 'main.css';
include 'functions.php';

$connection = dbConnect();

$query = "INSERT  INTO `blogposts` (`USERNAME`, `RESTAURANT_NAME`, `CUISINE_TYPE`, `ACTUAL_BLOG`)
    VALUES ('$userName', '$restuarantName', '$cuisine', '$blogPost')";

if ($connection -> query($query) === TRUE){
    echo "New blog post has been created successfully";
} else {
    echo "Error: " . $query . "<br>" . $connection -> error;
}
$close = connectionClose();
?>
<html>
			<a href="mainBlogPage.php"><button>Home</button></a>
			<button onclick="goBack()">Back</button>
		<script>
			function goBack(){
				window.history.back();}
		</script>
		<br>
</html>