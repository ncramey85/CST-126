<?php
include 'main.css';

$id = $_POST['id'];
$comment = $_POST['comment'];

include 'functions.php';
$connection = dbConnect();

$query = "INSERT INTO comments (`ID`, `COMMENTS`) VALUES ('$id', '$comment')";
echo "New comment added to Blog. <br><br>" . $comment;
    $close = connectionClose();
?>
<html>
		<button onclick="goBack()">Back</button>
		<a href="logoutBlog.php"><button>Logout</button></a>
	<script>
		function goBack(){
			window.history.back();
		}
	</script>
	<br>
</html>