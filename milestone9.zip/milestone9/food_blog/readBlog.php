<?php

    include 'main.css';
    include 'functions.php';
    
    $connection = dbConnect();
    
    $mysql = "SELECT * USERNAME, CUSINE_TYPE, RESTAURANT_NAME FROM blogposts";
    session_start();
    $userName = $_SESSION['userName'];
?>
<!DOCTYPE html>
<html>
	<body background="nasty.jpg">
		<h1 align="center"><strong> Chewing the fat through the blog.</strong></h1><br/>
			<a href="mainBlogPage.php"><button>Home</button></a>
			<button onclick="goBack()">Back</button>
		<script>
			function goBack(){
				window.history.back();}
		</script>
		<br>
		<?php $result = $connection -> query($mysql); ?>
    	<table id=blogTable style="background-color: #ff471a;">
    	   <tr style="color: #9999ff;">
    	   <strong>
            <th>ID</th>
            <th>User Name</th>
            <th>Restaurant Name</th>
            <th>Cuisine Type</th>
            <th>Blog</th>
            </strong>
            
           </tr> 
           <?php while ($row = $result -> fetch_assoc()): ?>
           <form method="post">
    	      <tr>
    	        <td> <?php echo $row["id"]; ?> </td>
    	        <td> <?php echo $row["userName"]; ?> </td>
    	        <td> <?php echo $row["restaurant_name"]; ?> </td>
    	        <td> <?php echo $row["cuisine"]; ?></td>
    	        <td> <?php echo $row["blogPost"]; ?> </td>
    	        <input type="hidden" name='hidden' value="$row['id']" > 
    	        <td> <input type="submit" formaction='commentsActual.php' name='comments' value='Comments' 
    	        style="background-color: #0088cc;"> </td>
    	       </tr>
    	    </form>
    	    <?php endwhile; ?>
    	</table>
    	<?php connectionClose(); ?>
	</body>
</html>
