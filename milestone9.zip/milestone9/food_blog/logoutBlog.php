<?php

session_start();
$_SESSION = array();
session_destroy();

echo "<h2 style='color: #004d99'>Logged out!</h2>
<br><br>
<h2 style='color: #004d99'> Happy Hunting eating in the Valley. </h2>";
?>